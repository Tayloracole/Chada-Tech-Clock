//Taylor Cole
//9/18/26
//Project One

#include "Clock.h"
#include <iostream>
#include <limits>

int main() {
	//Initialize clock with starting time (23:59:58)
	Clock myClock(23, 59, 58);
	int userSelection = 0; //Stores menu choice
	//Main Loop
	while (userSelection != 4) {
		myClock.displayClocks();
		myClock.displayMenu();
		//Validate that input is valid & integer
		if (!(std::cin >> userSelection)) {
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "\nInvalid input type. Enter a number between 1 and 4.\n";
			continue;
		}

		//Validate user choice/selection
		switch (userSelection) {
		case 1:
			myClock.addOneHour(); //Increment clock by 1 hour
			break;
		case 2:
			myClock.addOneMinute(); //Increment clock by 1 minute
			break;
		case 3:
			myClock.addOneSecond(); //Increment clock by 1 minute
			break;
		case 4:
			std::cout << "\nExiting application. Goodbye!\n"; //Exit Application
			break;
		default:
			std::cout << "\nInvalid selection. Choose an option from 1 to 4.\n"; //If invalid option; remind user to choose valid
			break;

			
		}
	}
	return 0;
}